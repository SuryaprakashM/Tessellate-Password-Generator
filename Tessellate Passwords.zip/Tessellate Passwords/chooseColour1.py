#!/usr/bin/python
 
#Making a hash table for colour so every colour corresponds to a number.
colour_table = {0: 'Violet', 1: 'Red', 2: 'Blue', 3: 'Green', 4: 'Yellow', 5: 'Pink', 6: 'Beige', 7: 'Orange', 8: 'Cyan', 9: 'Purple', 10: 'Brown', 11: 'Black', 12: 'White', 13: 'Gray', 14: 'Maroon'}
colour_table_size = 15
 
#Returning a colour from the look up table and the Key passed.
def getColour(number):
    return colour_table[(number%colour_table_size)]
