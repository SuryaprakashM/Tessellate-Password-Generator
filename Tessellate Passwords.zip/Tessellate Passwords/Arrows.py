#!/usr/bin/python

import turtle
import chooseColour
import RandNumGen

passwordID = input("Enter the password number :");
randomNumbers = RandNumGen.randomShuffle(passwordID)
turt1=turtle.Turtle()
width=5
height=4
count=0
for i in range(height):
        for j in range(width):
                count=count+1
                turt1.fillcolor(chooseColour.getColour( randomNumbers[count] ))
                turt1.speed('Fastest')
                turt1.begin_fill()
                turt1.forward(50)
                turt1.right(60)
                turt1.forward(25)
                turt1.right(60)
                turt1.forward(25)
                turt1.right(60)
                turt1.forward(50)
                turt1.right(120)
                turt1.forward(25)
                turt1.left(60)
                turt1.forward(25)
                turt1.right(120)
                turt1.penup()
                turt1.forward(51)
                turt1.pendown()
                turt1.end_fill()
        turt1.penup()
        turt1.backward(255.5)
        turt1.right(90)
        turt1.forward(43)
        turt1.left(90)
        turt1.pendown()

turtle.done()

