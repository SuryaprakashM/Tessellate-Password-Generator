#!/usr/bin/python
import turtle
import chooseColour
import RandNumGen
 
 
passwordID = input("Enter the password number:");
randomNumbers = RandNumGen.randomShuffle(passwordID)
wn=turtle.Screen()
t=turtle.Turtle()
count = 0
width=6
height=1
distance=60
t.color("red")
for x in range(height):
        for y in [0,1]:
                for i in range(width):
                        count = count + 1
                        t.fillcolor(chooseColour.getColour( count ))
                        t.begin_fill()
                        t.speed('fastest')
                        t.left(70)
                        t.forward(40)
                        t.right(70)
                        t.forward(60)
                        t.right(110)
                        t.forward(40)
                        t.right(70)
                        t.forward(60)
                        t.penup()
                        t.end_fill()
                        t.right(180)
                        t.forward(distance)
                        t.pendown()
 
                t.penup()
                t.backward(distance*width)
                t.pendown()
                for i in range(width):
                        count = count + 1
                        t.fillcolor(chooseColour.getColour( count ))
                        t.begin_fill()
                        t.right(70)
                        t.forward(40)
                        t.left(70)
                        t.forward(60)
                        t.left(110)
                        t.forward(40)
                        t.left(70)
                        t.forward(60)
                        t.penup()
                        t.end_fill()
                        t.right(180)
                        t.forward(distance)
                        t.pendown()
                t.backward(distance*(width))
                t.right(90)
                t.penup()
                t.forward(76)
                t.left(90)
                t.pendown()
 
turtle.done()
