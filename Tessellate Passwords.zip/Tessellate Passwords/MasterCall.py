#!/usr/bin/python
import random

value = random.randint(0,100)
if value%13 == 0:
	import Hexagon
	python (Hexagon.py)
elif value%17 ==0:
	import Arrows
	python (Arrows.py)
elif value%2 ==0:
	import Rhombus
	python (Rhombus.py)

	

