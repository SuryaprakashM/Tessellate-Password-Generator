#!/usr/bin/python
 
import turtle
import chooseColour
import RandNumGen
 
wn=turtle.Screen()
passwordID = input("Enter the password number.");
randomNumbers = RandNumGen.randomShuffle(passwordID)
t=turtle.Turtle()
count = 0 #Counting the number of shapes that have been drawn.
width=4
height=4
distance=90
t.color("red")
 
for x in range(height):
        for y in [0,1]:
                for i in range(width):
                        count = count + 1
                        t.fillcolor(chooseColour.getColour( randomNumbers[count] ) )
                        t.begin_fill()
                        t.left(60)
                        t.forward(30)
                        for n in [0,1,2,3,4]:
                                t.right(60)
                                t.forward(30)
                        t.penup()
                        t.end_fill()
                        t.right(120)
                        t.forward(distance)
                        t.pendown()
 
                t.penup()
                t.backward(distance*width)
                t.right(90)
                t.forward(26)
                t.left(90)
                t.forward(45)
                t.pendown()
        t.penup()
        t.backward(90)
        t.pendown()
 
turtle.done()
